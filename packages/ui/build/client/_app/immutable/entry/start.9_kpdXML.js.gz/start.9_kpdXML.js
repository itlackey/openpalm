import{a as r}from"../chunks/BIPdtRdT.js";import{y as t}from"../chunks/DwlCIXL_.js";export{t as load_css,r as start};
